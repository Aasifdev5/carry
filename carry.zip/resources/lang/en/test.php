<?php

return [
   'dashboard' => 'dashboard',
   'Vehicle Management' => 'Vehicle Management',
   'Add Vehicle' => 'Add Vehicle',
   'Vehicle List' => 'Vehicle List',
   'Vehicle' => 'Vehicle',
   'Users Management' => 'Users Management',
   'Users List' => 'Users List',
   'Push Notification' => 'Push Notification',
   'Premium Plan' => 'Premium Plan',
   'Currency' => 'Currency',
   'Luggage Type' => 'Luggage Type',
   'Language Management' => 'Language Management',
   'Languages' => 'Languages',
   'MultiLingual' => 'MultiLingual',
   'Payment Interface Settings' => 'Payment Interface Settings',
   'Matches List' => 'Matches List',
   'User Terms' => 'User Terms',
   'User Limitation' => 'User Limitation',
   'Changed Password' => 'Changed Password',
   'Logout' => 'Logout',
   'Add' => 'Add',
   'Edit' => 'Edit',
   'Save' => 'Save',
   'Update' => 'Update',
   'List' => 'List',
   'Hello ' => 'Hello',
   'Invited Users' => 'Invited Users',
   'Distributor Management' => 'Distributor Management',
   'Distributor' => 'Distributor'

];
