<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Users extends Model
{
    protected $table = 'user_limitation';
    protected $fillable = ['user_type', 'lang_id', 'workman_id', 'email', 'password', 'invite_code', 'security_date', 'name', 'profile_photo'];
}
